part of 'qr_cubit.dart';

abstract class QrState {}

class QrInitial extends QrState {
  QrInitial();
}

class QrError extends QrState {
  QrError();
}

class QrOpen extends QrState {}

class QrSuccess extends QrState {
  QrSuccess({required this.openSheet});
  bool openSheet;
}

class QrLoading extends QrState {
  QrLoading();
}
