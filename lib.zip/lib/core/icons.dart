class MyIcons {
////   ... svg
  static const home = "assets/svg/home.svg";
  static const profile = "assets/svg/profile.svg";
  static const refresh = "assets/svg/refresh.svg";
  static const books = "assets/svg/books.svg";

////  .. png

  static const cta = "assets/png/CTA.png";
  static const phone = "assets/png/Phone.png";
  static const profileIcon = "assets/png/profile_icon.png";
  static const rectangle = "assets/Rectangle.png";
}
