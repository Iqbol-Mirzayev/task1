import 'package:flutter/material.dart';

class MyColors {
  static final cont1 = Color(0xffDFF1FF);
  static final cont2 = Color(0xffFEE5E9);
  
  static final colorEF476F = Color(0xffEF476F);
  static final backColor = Color(0xff073B4C);

}
